class complex extends uvm_sequence_item;

  // --------------------------
  // Constructor
  // --------------------------
  function new(string name = "complex");
    super.new(name);
  endfunction

/*-------------------------------------------------------------------------------
-- Fields
-------------------------------------------------------------------------------*/
  rand bit [15:0] real;   // Real part
  rand bit [15:0] imag;   // Imaginary part
  complex_config  cnum_cfg;

  // --------------------------
  // Factory + Field Macros
  // --------------------------
  `uvm_object_utils_begin(complex)
    `uvm_field_int(real, UVM_ALL_ON|UVM_NOCOMPARE)
    `uvm_field_int(imag, UVM_ALL_ON|UVM_NOCOMPARE)
  `uvm_object_utils_end

  // --------------------------
  // Clone method
  // --------------------------
  function complex clone;
    complex p;
    $cast(p, super.clone());
    return p;
  endfunction

  // --------------------------
  // Display helper
  // --------------------------
  virtual function void display_complex(string name);
    string msg;
    
    msg = $sformatf("\n This is being displayed from %s \n", name);
    msg = {msg, "================================================================\n"};
    msg = {msg, $sformatf("Real = %0d, Imag = %0d \n", real, imag)};
    `uvm_info(name, msg, UVM_MEDIUM)
  endfunction 

endclass // complex

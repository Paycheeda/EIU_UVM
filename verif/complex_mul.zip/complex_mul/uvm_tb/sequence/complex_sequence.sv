class complex_sequence extends uvm_sequence #(inp_complex);
  `uvm_object_utils(complex_sequence)

  // Transaction item
  inp_complex    cnum;

  // Config for controlling sequence randomization
  complex_config cnum_cfg;   

  int num_cnums;   // total complex numbers to generate
  int i;           // loop counter
  int min_real, max_real;
  int min_imag, max_imag;

  // ---------------------------------
  // Constructor
  // ---------------------------------
  function new (string name = "complex_sequence");
    super.new(name); 
  endfunction 

  // ---------------------------------
  // Pre-start Phase
  // ---------------------------------
  virtual task pre_start();
    if (!uvm_config_db#(complex_config)::get(get_sequencer(), "", "cnum_cfg", cnum_cfg))
      `uvm_fatal("complex_sequence", "Did not get complex Config")
  endtask 
  
  // ---------------------------------
  // Body Task (Generate Sequence Items)
  // ---------------------------------
  virtual task body();
    cnum = inp_complex::type_id::create("cnum");

    `uvm_info("complex_sequence", 
              $sformatf("Generating Complex Numbers = %0d", num_cnums), 
              UVM_MEDIUM)

    // Get min/max from config
    min_real = cnum_cfg.real_min;
    max_real = cnum_cfg.real_max;
    min_imag = cnum_cfg.imag_min;
    max_imag = cnum_cfg.imag_max;

    // Loop and generate sequence items
    for (i = 0; i < num_cnums; i++)  begin
      start_item(cnum);

      // Assign values for this transaction
      cnum.real = $urandom_range(min_real, max_real);
      cnum.imag = $urandom_range(min_imag, max_imag);

      finish_item(cnum);  
    end

    `uvm_info("complex_sequence", 
              $sformatf("Done generation of %0d complex number items", i), 
              UVM_LOW)
  endtask // body

endclass // complex_sequence
